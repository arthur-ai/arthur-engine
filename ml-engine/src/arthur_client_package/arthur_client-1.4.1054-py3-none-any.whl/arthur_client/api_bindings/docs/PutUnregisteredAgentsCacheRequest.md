# PutUnregisteredAgentsCacheRequest

Request body for uploading unregistered agents cache.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unregistered_agents_data** | [**List[CachedUnregisteredAgent]**](CachedUnregisteredAgent.md) | Cached unregistered agents data from the data plane. | 

## Example

```python
from arthur_client.api_bindings.models.put_unregistered_agents_cache_request import PutUnregisteredAgentsCacheRequest

# TODO update the JSON string below
json = "{}"
# create an instance of PutUnregisteredAgentsCacheRequest from a JSON string
put_unregistered_agents_cache_request_instance = PutUnregisteredAgentsCacheRequest.from_json(json)
# print the JSON string representation of the object
print(PutUnregisteredAgentsCacheRequest.to_json())

# convert the object into a dict
put_unregistered_agents_cache_request_dict = put_unregistered_agents_cache_request_instance.to_dict()
# create an instance of PutUnregisteredAgentsCacheRequest from a dict
put_unregistered_agents_cache_request_from_dict = PutUnregisteredAgentsCacheRequest.from_dict(put_unregistered_agents_cache_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


