# ApiModelsUnregisteredAgentsCreationSource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task_id** | **str** |  | [optional] 
**top_level_span_name** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.api_models_unregistered_agents_creation_source import ApiModelsUnregisteredAgentsCreationSource

# TODO update the JSON string below
json = "{}"
# create an instance of ApiModelsUnregisteredAgentsCreationSource from a JSON string
api_models_unregistered_agents_creation_source_instance = ApiModelsUnregisteredAgentsCreationSource.from_json(json)
# print the JSON string representation of the object
print(ApiModelsUnregisteredAgentsCreationSource.to_json())

# convert the object into a dict
api_models_unregistered_agents_creation_source_dict = api_models_unregistered_agents_creation_source_instance.to_dict()
# create an instance of ApiModelsUnregisteredAgentsCreationSource from a dict
api_models_unregistered_agents_creation_source_from_dict = ApiModelsUnregisteredAgentsCreationSource.from_dict(api_models_unregistered_agents_creation_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


