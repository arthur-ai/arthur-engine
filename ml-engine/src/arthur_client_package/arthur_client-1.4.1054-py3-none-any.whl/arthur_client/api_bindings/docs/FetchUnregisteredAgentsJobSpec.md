# FetchUnregisteredAgentsJobSpec


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_type** | **str** |  | [optional] [default to 'fetch_unregistered_agents']
**data_plane_id** | **str** | The id of the data plane to fetch unregistered agents from. | 
**workspace_id** | **str** | The id of the workspace the data plane belongs to. | 

## Example

```python
from arthur_client.api_bindings.models.fetch_unregistered_agents_job_spec import FetchUnregisteredAgentsJobSpec

# TODO update the JSON string below
json = "{}"
# create an instance of FetchUnregisteredAgentsJobSpec from a JSON string
fetch_unregistered_agents_job_spec_instance = FetchUnregisteredAgentsJobSpec.from_json(json)
# print the JSON string representation of the object
print(FetchUnregisteredAgentsJobSpec.to_json())

# convert the object into a dict
fetch_unregistered_agents_job_spec_dict = fetch_unregistered_agents_job_spec_instance.to_dict()
# create an instance of FetchUnregisteredAgentsJobSpec from a dict
fetch_unregistered_agents_job_spec_from_dict = FetchUnregisteredAgentsJobSpec.from_dict(fetch_unregistered_agents_job_spec_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


