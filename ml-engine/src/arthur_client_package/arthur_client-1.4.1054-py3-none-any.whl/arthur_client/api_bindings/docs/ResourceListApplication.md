# ResourceListApplication


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[Application]**](Application.md) | List of records. | 
**pagination** | [**Pagination**](Pagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.resource_list_application import ResourceListApplication

# TODO update the JSON string below
json = "{}"
# create an instance of ResourceListApplication from a JSON string
resource_list_application_instance = ResourceListApplication.from_json(json)
# print the JSON string representation of the object
print(ResourceListApplication.to_json())

# convert the object into a dict
resource_list_application_dict = resource_list_application_instance.to_dict()
# create an instance of ResourceListApplication from a dict
resource_list_application_from_dict = ResourceListApplication.from_dict(resource_list_application_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


