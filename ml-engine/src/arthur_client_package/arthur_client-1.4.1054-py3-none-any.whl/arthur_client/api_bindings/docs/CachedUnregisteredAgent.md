# CachedUnregisteredAgent

Unregistered agent data for caching.  This model is used for the cache API - infrastructure is not included because it is derived from the data plane when reading from cache.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creation_source** | [**CachedCreationSource**](CachedCreationSource.md) | Source information for identifying where the agent is coming from. | 
**first_detected** | **datetime** | Timestamp when the agent was first detected. | 
**num_spans** | **int** | Number of spans associated with this agent. | 

## Example

```python
from arthur_client.api_bindings.models.cached_unregistered_agent import CachedUnregisteredAgent

# TODO update the JSON string below
json = "{}"
# create an instance of CachedUnregisteredAgent from a JSON string
cached_unregistered_agent_instance = CachedUnregisteredAgent.from_json(json)
# print the JSON string representation of the object
print(CachedUnregisteredAgent.to_json())

# convert the object into a dict
cached_unregistered_agent_dict = cached_unregistered_agent_instance.to_dict()
# create an instance of CachedUnregisteredAgent from a dict
cached_unregistered_agent_from_dict = CachedUnregisteredAgent.from_dict(cached_unregistered_agent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


