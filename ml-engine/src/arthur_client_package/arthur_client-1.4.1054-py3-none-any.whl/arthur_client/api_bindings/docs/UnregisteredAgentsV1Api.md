# arthur_client.api_bindings.UnregisteredAgentsV1Api

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**fetch_unregistered_agents**](UnregisteredAgentsV1Api.md#fetch_unregistered_agents) | **POST** /api/v1/workspaces/{workspace_id}/unregistered_agents/fetch | Fetch Unregistered Agents
[**list_unregistered_agents**](UnregisteredAgentsV1Api.md#list_unregistered_agents) | **GET** /api/v1/workspaces/{workspace_id}/unregistered_agents | List Unregistered Agents
[**put_unregistered_agents_cache**](UnregisteredAgentsV1Api.md#put_unregistered_agents_cache) | **PUT** /api/v1/workspaces/{workspace_id}/unregistered_agents/cache/{data_plane_id} | Upload Unregistered Agents Cache


# **fetch_unregistered_agents**
> fetch_unregistered_agents(workspace_id)

Fetch Unregistered Agents

Triggers a job to fetch unregistered agents from all GenAI-enabled data planes in the workspace. Requires workspace_governance_view permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.UnregisteredAgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 

    try:
        # Fetch Unregistered Agents
        api_instance.fetch_unregistered_agents(workspace_id)
    except Exception as e:
        print("Exception when calling UnregisteredAgentsV1Api->fetch_unregistered_agents: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_unregistered_agents**
> ResourceListUnregisteredAgent list_unregistered_agents(workspace_id, page=page, page_size=page_size)

List Unregistered Agents

Returns a list of unregistered agents for the workspace. Requires workspace_governance_view permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_unregistered_agent import ResourceListUnregisteredAgent
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.UnregisteredAgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Unregistered Agents
        api_response = api_instance.list_unregistered_agents(workspace_id, page=page, page_size=page_size)
        print("The response of UnregisteredAgentsV1Api->list_unregistered_agents:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UnregisteredAgentsV1Api->list_unregistered_agents: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListUnregisteredAgent**](ResourceListUnregisteredAgent.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_unregistered_agents_cache**
> put_unregistered_agents_cache(workspace_id, data_plane_id, put_unregistered_agents_cache_request)

Upload Unregistered Agents Cache

Upload cached unregistered agents data from a data plane. Internal endpoint used by job executors.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.put_unregistered_agents_cache_request import PutUnregisteredAgentsCacheRequest
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.UnregisteredAgentsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    data_plane_id = 'data_plane_id_example' # str | The ID of the data plane. Should be formatted as a UUID.
    put_unregistered_agents_cache_request = arthur_client.api_bindings.PutUnregisteredAgentsCacheRequest() # PutUnregisteredAgentsCacheRequest | 

    try:
        # Upload Unregistered Agents Cache
        api_instance.put_unregistered_agents_cache(workspace_id, data_plane_id, put_unregistered_agents_cache_request)
    except Exception as e:
        print("Exception when calling UnregisteredAgentsV1Api->put_unregistered_agents_cache: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **data_plane_id** | **str**| The ID of the data plane. Should be formatted as a UUID. | 
 **put_unregistered_agents_cache_request** | [**PutUnregisteredAgentsCacheRequest**](PutUnregisteredAgentsCacheRequest.md)|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

