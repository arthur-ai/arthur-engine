# CachedCreationSource

Creation source info for cached unregistered agents.  Uses string for task_id to match the format from ml-engine.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task_id** | **str** |  | [optional] 
**top_level_span_name** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.cached_creation_source import CachedCreationSource

# TODO update the JSON string below
json = "{}"
# create an instance of CachedCreationSource from a JSON string
cached_creation_source_instance = CachedCreationSource.from_json(json)
# print the JSON string representation of the object
print(CachedCreationSource.to_json())

# convert the object into a dict
cached_creation_source_dict = cached_creation_source_instance.to_dict()
# create an instance of CachedCreationSource from a dict
cached_creation_source_from_dict = CachedCreationSource.from_dict(cached_creation_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


