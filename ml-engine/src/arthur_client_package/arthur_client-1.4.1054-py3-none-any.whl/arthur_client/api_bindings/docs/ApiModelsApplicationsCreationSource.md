# ApiModelsApplicationsCreationSource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task_id** | **str** |  | [optional] 
**top_level_span_name** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.api_models_applications_creation_source import ApiModelsApplicationsCreationSource

# TODO update the JSON string below
json = "{}"
# create an instance of ApiModelsApplicationsCreationSource from a JSON string
api_models_applications_creation_source_instance = ApiModelsApplicationsCreationSource.from_json(json)
# print the JSON string representation of the object
print(ApiModelsApplicationsCreationSource.to_json())

# convert the object into a dict
api_models_applications_creation_source_dict = api_models_applications_creation_source_instance.to_dict()
# create an instance of ApiModelsApplicationsCreationSource from a dict
api_models_applications_creation_source_from_dict = ApiModelsApplicationsCreationSource.from_dict(api_models_applications_creation_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


