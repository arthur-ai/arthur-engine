# arthur_client.api_bindings.ApplicationsV1Api

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_application**](ApplicationsV1Api.md#create_application) | **POST** /api/v1/workspaces/{workspace_id}/application | Create Application
[**delete_application**](ApplicationsV1Api.md#delete_application) | **DELETE** /api/v1/workspaces/{workspace_id}/application/{application_id} | Delete Application
[**get_application**](ApplicationsV1Api.md#get_application) | **GET** /api/v1/workspaces/{workspace_id}/application/{application_id} | Get Application
[**list_applications**](ApplicationsV1Api.md#list_applications) | **GET** /api/v1/workspaces/{workspace_id}/application | List Applications
[**update_application**](ApplicationsV1Api.md#update_application) | **PATCH** /api/v1/workspaces/{workspace_id}/application/{application_id} | Update Application


# **create_application**
> Application create_application(workspace_id, post_application)

Create Application

Creates a new application. Requires workspace_governance_view permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.application import Application
from arthur_client.api_bindings.models.post_application import PostApplication
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.ApplicationsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    post_application = arthur_client.api_bindings.PostApplication() # PostApplication | 

    try:
        # Create Application
        api_response = api_instance.create_application(workspace_id, post_application)
        print("The response of ApplicationsV1Api->create_application:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ApplicationsV1Api->create_application: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **post_application** | [**PostApplication**](PostApplication.md)|  | 

### Return type

[**Application**](Application.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_application**
> delete_application(workspace_id, application_id)

Delete Application

Deletes an application. Requires workspace_governance_view permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.ApplicationsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    application_id = 'application_id_example' # str | The ID of the application. Should be formatted as a UUID.

    try:
        # Delete Application
        api_instance.delete_application(workspace_id, application_id)
    except Exception as e:
        print("Exception when calling ApplicationsV1Api->delete_application: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **application_id** | **str**| The ID of the application. Should be formatted as a UUID. | 

### Return type

void (empty response body)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_application**
> Application get_application(workspace_id, application_id)

Get Application

Returns a single application by ID. Requires workspace_governance_view permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.application import Application
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.ApplicationsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    application_id = 'application_id_example' # str | The ID of the application. Should be formatted as a UUID.

    try:
        # Get Application
        api_response = api_instance.get_application(workspace_id, application_id)
        print("The response of ApplicationsV1Api->get_application:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ApplicationsV1Api->get_application: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **application_id** | **str**| The ID of the application. Should be formatted as a UUID. | 

### Return type

[**Application**](Application.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_applications**
> ResourceListApplication list_applications(workspace_id, page=page, page_size=page_size)

List Applications

Returns a list of applications for the workspace. Requires workspace_governance_view permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_application import ResourceListApplication
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.ApplicationsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Applications
        api_response = api_instance.list_applications(workspace_id, page=page, page_size=page_size)
        print("The response of ApplicationsV1Api->list_applications:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ApplicationsV1Api->list_applications: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListApplication**](ResourceListApplication.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_application**
> Application update_application(workspace_id, application_id, patch_application)

Update Application

Updates an application. Requires workspace_governance_view permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.application import Application
from arthur_client.api_bindings.models.patch_application import PatchApplication
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.ApplicationsV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    application_id = 'application_id_example' # str | The ID of the application. Should be formatted as a UUID.
    patch_application = arthur_client.api_bindings.PatchApplication() # PatchApplication | 

    try:
        # Update Application
        api_response = api_instance.update_application(workspace_id, application_id, patch_application)
        print("The response of ApplicationsV1Api->update_application:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ApplicationsV1Api->update_application: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **application_id** | **str**| The ID of the application. Should be formatted as a UUID. | 
 **patch_application** | [**PatchApplication**](PatchApplication.md)|  | 

### Return type

[**Application**](Application.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

