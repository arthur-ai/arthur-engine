# PatchApplication


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_name** | **str** |  | [optional] 
**application_description** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.patch_application import PatchApplication

# TODO update the JSON string below
json = "{}"
# create an instance of PatchApplication from a JSON string
patch_application_instance = PatchApplication.from_json(json)
# print the JSON string representation of the object
print(PatchApplication.to_json())

# convert the object into a dict
patch_application_dict = patch_application_instance.to_dict()
# create an instance of PatchApplication from a dict
patch_application_from_dict = PatchApplication.from_dict(patch_application_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


