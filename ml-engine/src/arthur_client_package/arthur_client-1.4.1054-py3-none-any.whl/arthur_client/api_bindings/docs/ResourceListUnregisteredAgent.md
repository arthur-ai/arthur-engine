# ResourceListUnregisteredAgent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[UnregisteredAgent]**](UnregisteredAgent.md) | List of records. | 
**pagination** | [**Pagination**](Pagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.resource_list_unregistered_agent import ResourceListUnregisteredAgent

# TODO update the JSON string below
json = "{}"
# create an instance of ResourceListUnregisteredAgent from a JSON string
resource_list_unregistered_agent_instance = ResourceListUnregisteredAgent.from_json(json)
# print the JSON string representation of the object
print(ResourceListUnregisteredAgent.to_json())

# convert the object into a dict
resource_list_unregistered_agent_dict = resource_list_unregistered_agent_instance.to_dict()
# create an instance of ResourceListUnregisteredAgent from a dict
resource_list_unregistered_agent_from_dict = ResourceListUnregisteredAgent.from_dict(resource_list_unregistered_agent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


