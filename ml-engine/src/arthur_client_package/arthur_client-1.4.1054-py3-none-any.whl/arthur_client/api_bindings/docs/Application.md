# Application


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Time of record creation. | 
**updated_at** | **datetime** | Time of last record update. | 
**application_id** | **str** | ID of the application. | 
**application_name** | **str** | Name of the application. | 
**application_description** | **str** |  | [optional] 
**task_id** | **str** |  | [optional] 
**infrastructure** | [**Infrastructure**](Infrastructure.md) | Infrastructure where the application is running (e.g., AWS, GCP, Azure, PRIVATE). | 
**rag_status** | [**ApplicationStatus**](ApplicationStatus.md) | RAG status of the application (red, yellow, green). | 
**agents** | [**List[Agent]**](Agent.md) | List of agents associated with this application. | [optional] 
**tools** | [**List[Tool]**](Tool.md) | List of tools associated with this application. | [optional] 

## Example

```python
from arthur_client.api_bindings.models.application import Application

# TODO update the JSON string below
json = "{}"
# create an instance of Application from a JSON string
application_instance = Application.from_json(json)
# print the JSON string representation of the object
print(Application.to_json())

# convert the object into a dict
application_dict = application_instance.to_dict()
# create an instance of Application from a dict
application_from_dict = Application.from_dict(application_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


