# PostApplication


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_name** | **str** | Name of the application. | 
**application_description** | **str** | Description of the application. | 
**creation_source** | [**ApiModelsApplicationsCreationSource**](ApiModelsApplicationsCreationSource.md) | Source information for how this application was created. | 
**infrastructure** | [**Infrastructure**](Infrastructure.md) | Infrastructure where the application is running (e.g., AWS, GCP, Azure, PRIVATE). | 

## Example

```python
from arthur_client.api_bindings.models.post_application import PostApplication

# TODO update the JSON string below
json = "{}"
# create an instance of PostApplication from a JSON string
post_application_instance = PostApplication.from_json(json)
# print the JSON string representation of the object
print(PostApplication.to_json())

# convert the object into a dict
post_application_dict = post_application_instance.to_dict()
# create an instance of PostApplication from a dict
post_application_from_dict = PostApplication.from_dict(post_application_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


