# UnregisteredAgent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creation_source** | [**ApiModelsApplicationsCreationSource**](ApiModelsApplicationsCreationSource.md) | Source information for identifying where the agent is coming from. | 
**first_detected** | **datetime** | Timestamp when the agent was first detected. | 
**num_spans** | **int** | Number of spans associated with this agent. | 
**infrastructure** | [**Infrastructure**](Infrastructure.md) | Infrastructure where the agent was detected (e.g., AWS, GCP, Azure, PRIVATE). | 

## Example

```python
from arthur_client.api_bindings.models.unregistered_agent import UnregisteredAgent

# TODO update the JSON string below
json = "{}"
# create an instance of UnregisteredAgent from a JSON string
unregistered_agent_instance = UnregisteredAgent.from_json(json)
# print the JSON string representation of the object
print(UnregisteredAgent.to_json())

# convert the object into a dict
unregistered_agent_dict = unregistered_agent_instance.to_dict()
# create an instance of UnregisteredAgent from a dict
unregistered_agent_from_dict = UnregisteredAgent.from_dict(unregistered_agent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


